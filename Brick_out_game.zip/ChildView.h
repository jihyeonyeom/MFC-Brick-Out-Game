﻿
// ChildView.h: CChildView 클래스의 인터페이스
//


#pragma once


// CChildView 창

class CChildView : public CWnd
{
// 생성입니다.
public:
	CChildView();

// 특성입니다.
public:

// 작업입니다.
public:

// 재정의입니다.
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// 구현입니다.
public:
	virtual ~CChildView();

	// 생성된 메시지 맵 함수
protected:
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
public:
	// 바 생성 반환 함수
	CRect Bar();
	// 현재 바 위치
	CPoint Bar_position;
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	// 공 반환 함수
	CRect Ball();
	// 현재 공 위치
	CPoint Ball_position;
	// 공 반지름
	int Ball_radius;
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	// 공 속도
	int b_speedx;
	int b_speedy;
	//블럭 생성
	int bricks[4][7];
	//공 방향
	int x_way;
	int y_way;
	//블럭 개수 카운트
	int CountBlock;
	//안내창 카운트
	int Afx_Count;
	//목숨
	int life;
};

