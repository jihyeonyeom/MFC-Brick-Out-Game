﻿
// ChildView.cpp: CChildView 클래스의 구현
//

#include "pch.h"
#include "framework.h"
#include "Brick_out_game.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
	Afx_Count = 0;
	b_speedx = 10;
	b_speedy = 9;
	CountBlock = 0;
	life = 0;
	x_way = 1;
	y_way = 1;
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 7; j++)
			bricks[i][j] = 1;
	}
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_CREATE()
	ON_WM_KEYDOWN()
	ON_WM_TIMER()
END_MESSAGE_MAP()



// CChildView 메시지 처리기

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS,
		::LoadCursor(nullptr, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1), nullptr);

	return TRUE;
}

void CChildView::OnPaint()
{
	CPaintDC dc(this); // 그리기를 위한 디바이스 컨텍스트입니다.

	//---------------- 기둥 생성 --------------------

	CBrush brush, * pBrush;
	brush.CreateSolidBrush(RGB(224, 132, 79));
	pBrush = dc.SelectObject(&brush);
	// 기둥 너비 x1 = 120, y1 = 50, x2 = 680, y2 = 650
	dc.Rectangle(100, 30, 120, 650);//왼쪽 벽
	dc.Rectangle(680, 30, 700, 650);//오른쪽 벽
	dc.Rectangle(120, 30, 680, 50);//위쪽 벽
	dc.Rectangle(100, 650, 700, 670);//아래쪽 벽
	dc.SelectObject(pBrush);
	brush.DeleteObject();

	//---------------- 공, 바 생성 --------------------

	brush.CreateSolidBrush(RGB(241, 95, 95));
	pBrush = dc.SelectObject(&brush);
	dc.Rectangle(Bar()); //바 생성
	dc.Ellipse(Ball()); //공 생성
	dc.SelectObject(pBrush);
	brush.DeleteObject();

	//---------------- 블럭 생성 --------------------

	int i, j = 0;
	int x = 120, y = 50; // 기둥 x, y축
	brush.CreateSolidBrush(RGB(103, 153, 255));
	pBrush = dc.SelectObject(&brush);
	for (i = 0; i < 4; i++) {
		for (j = 0; j < 7; j++) {
			if (bricks[i][j] == 1)
				dc.Rectangle((x + j * 80), (y + i * 40), (x + (j + 1) * 80), (y + (i + 1) * 40));
		}//for(j)
	}//for(i)
	dc.SelectObject(pBrush);
	brush.DeleteObject();
	//---------------- 안내 멘트 --------------------
	if (Afx_Count == 0) {
		AfxMessageBox(_T("↑방향키를 누르면 시작합니다.\n←→방향키로 바를 움직입니다.\n↓방향키를 누르면 재도전."));
		Afx_Count++;
	}
}

CRect CChildView::Bar()
{
	return CRect(Bar_position.x - 40, Bar_position.y - 10, Bar_position.x + 40, Bar_position.y + 10);
}

int CChildView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	Bar_position = CPoint(400, 580); //초기 위치
	Ball_position = CPoint(400, 330);
	Ball_radius = 7;

	return 0;
}

void CChildView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	switch (nChar)
	{
	case VK_LEFT:
		if (Bar_position.x <= 180) {
			Bar_position.x = 180;
		}
		Bar_position.x -= 20;
		break;
	case VK_RIGHT:
		if (Bar_position.x >= 620) {
			Bar_position.x = 620;
		}
		Bar_position.x += 20;
		break;
	case VK_UP:
		SetTimer(0, 45, NULL);
		break;
	case VK_DOWN:
		if (life == 1) {
			Ball_position = CPoint(400, 330);
			life = 0;
			x_way = 1;
			y_way = 1;
			b_speedx = 10;
			b_speedy = 9;
			CountBlock = 0;
			for (int i = 0; i < 4; i++) {
				for (int j = 0; j < 7; j++)
					bricks[i][j] = 1;
			}
		}
		break;
	}//switch
	Invalidate();
	CWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}

CRect CChildView::Ball()
{
	return CRect(Ball_position.x - Ball_radius,
		Ball_position.y - Ball_radius,
		Ball_position.x + Ball_radius,
		Ball_position.y + Ball_radius);
}

void CChildView::OnTimer(UINT_PTR nIDEvent)
{
	CClientDC dc(this);
	Ball_position.x += b_speedx * x_way;
	Ball_position.y += b_speedy * y_way;

	//바운더리 처리
	//--------------기둥과의 충돌처리----------------
	if (Ball_position.x <= 127 || Ball_position.x >= 672) { //왼쪽, 오른쪽 벽 
		//공이 벽을 파고들지 않게 설정
		if (Ball_position.x <= 127)
			Ball_position.x = 127;
		if (Ball_position.x >= 672)
			Ball_position.x = 672;
		x_way *= -1;
	}
	if (Ball_position.y <= 57) { //윗쪽 벽
		//공이 벽을 파고들지 않게 설정
		if (Ball_position.y <= 57)
			Ball_position.y = 57;
		y_way *= -1;
	}
	//--------------바와의 충돌처리----------------
	{
		//왼쪽면을 오른쪽 아래 대각선으로 이동하는 공이 맞았을 경우
		if ((Bar_position.x - 40 <= Ball_position.x && Bar_position.x - 10 >= Ball_position.x) &&
			(Bar_position.y - 10 >= Ball_position.y && Bar_position.y - 10 - Ball_radius <= Ball_position.y) && (y_way == 1)) {
			if (x_way == 1) {
				if (b_speedy == 13) {
					Ball_position.y = Bar_position.y - 10 - Ball_radius; // 바에 공이 박히는거 방지
					y_way *= -1;
					b_speedy = 9;
				}
				else if (b_speedy == 9) {
					Ball_position.y = Bar_position.y - 10 - Ball_radius; // 바에 공이 박히는거 방지
					y_way *= -1;
					b_speedy = 7;
				}
				else if (b_speedy == 7) {
					Ball_position.y = Bar_position.y - 10 - Ball_radius; // 바에 공이 박히는거 방지
					y_way *= -1;
				}
			}
			//왼쪽면을 왼쪽 아래 대각선으로 이동하는 공이 맞았을 경우
			else if (x_way == -1) {
				if (b_speedy == 13) {
					Ball_position.y = Bar_position.y - 10 - Ball_radius; // 바에 공이 박히는거 방지
					y_way *= -1;
				}
				else if (b_speedy == 9) {
					Ball_position.y = Bar_position.y - 10 - Ball_radius; // 바에 공이 박히는거 방지
					y_way *= -1;
					b_speedy = 13;
				}
				else if (b_speedy == 7) {
					Ball_position.y = Bar_position.y - 10 - Ball_radius; // 바에 공이 박히는거 방지
					y_way *= -1;
					b_speedy = 9;
				}
			}
		}
		//가운데면 맞았을 경우
		else if ((Bar_position.x - 10 <= Ball_position.x && Bar_position.x + 10 >= Ball_position.x) &&
			(Bar_position.y - 10 >= Ball_position.y && Bar_position.y - 10 - Ball_radius <= Ball_position.y) && (y_way == 1)) {
			if (b_speedy == 13) {
				Ball_position.y = Bar_position.y - 10 - Ball_radius; // 바에 공이 박히는거 방지
				y_way *= -1;
				b_speedy = 9;
			}
			else if (b_speedy == 9) {
				Ball_position.y = Bar_position.y - 10 - Ball_radius; // 바에 공이 박히는거 방지
				y_way *= -1;
			}
			else if (b_speedy == 7) {
				Ball_position.y = Bar_position.y - 10 - Ball_radius; // 바에 공이 박히는거 방지
				y_way *= -1;
				b_speedy = 9;
			}
		}
		//오른쪽면을 왼쪽 아래 대각선으로 이동하는 공이 맞았을 경우
		else if ((Bar_position.x + 10 <= Ball_position.x && Bar_position.x + 40 >= Ball_position.x) &&
			(Bar_position.y - 10 >= Ball_position.y && Bar_position.y - 10 - Ball_radius <= Ball_position.y) && (y_way == 1)) {
			if (x_way == -1) {
				if (b_speedy == 13) {
					Ball_position.y = Bar_position.y - 10 - Ball_radius; // 바에 공이 박히는거 방지
					y_way *= -1;
					b_speedy = 9;
				}
				else if (b_speedy == 9) {
					Ball_position.y = Bar_position.y - 10 - Ball_radius; // 바에 공이 박히는거 방지
					y_way *= -1;
					b_speedy = 7;
				}
				else if (b_speedy == 7) {
					Ball_position.y = Bar_position.y - 10 - Ball_radius; // 바에 공이 박히는거 방지
					y_way *= -1;
				}
			}
			//오른쪽면을 오른쪽 아래 대각선으로 이동하는 공이 맞았을 경우
			else if (x_way == 1) {
				if (b_speedy == 13) {
					Ball_position.y = Bar_position.y - 10 - Ball_radius; // 바에 공이 박히는거 방지
					y_way *= -1;
				}
				else if (b_speedy == 9) {
					Ball_position.y = Bar_position.y - 10 - Ball_radius; // 바에 공이 박히는거 방지
					y_way *= -1;
					b_speedy = 13;
				}
				else if (b_speedy == 7) {
					Ball_position.y = Bar_position.y - 10 - Ball_radius; // 바에 공이 박히는거 방지
					y_way *= -1;
					b_speedy = 9;
				}
			}
		}
		//왼쪽 모서리 맞았을 때
		else if ((Bar_position.x - 40 - Ball_radius <= Ball_position.x && Bar_position.x - 40 >= Ball_position.x) &&
			(Bar_position.y - 10 >= Ball_position.y && Bar_position.y - 10 - Ball_radius <= Ball_position.y) && (x_way == 1)) {
			x_way *= -1;
			y_way *= -1;
		}
		//오른쪽 모서리 맞았을 때
		else if ((Bar_position.x + 40 <= Ball_position.x && Bar_position.x + 40 + Ball_radius >= Ball_position.x) &&
			(Bar_position.y - 10 >= Ball_position.y && Bar_position.y - 10 - Ball_radius <= Ball_position.y) && (x_way == -1)) {
			x_way *= -1;
			y_way *= -1;
		}
	}
	//--------------블럭과의 충돌처리----------------
	int blockX = 0;		//벽돌이 있을때의 그 x좌표를 기억하는 임시변수
	int blockY = 0;		//벽돌이 있을때의 그 y좌표를 기억하는 임시변수
	int x = 120, y = 50; // 기둥 안쪽 기준점 x, y축
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 7; j++) {
			if (bricks[i][j] == 1) {
				blockX = x + j * 80;
				blockY = y + i * 40;
				if ((blockX <= Ball_position.x && blockX + 80 >= Ball_position.x) && (blockY + 40 <= Ball_position.y && blockY + 40 + Ball_radius >= Ball_position.y) && (y_way == -1)) {
					//아래쪽 맞았을 때 
					Ball_position.y = blockY + 40 + Ball_radius; // 블럭에 공이 박히는거 방지
					y_way *= -1; // 방향 전환
					bricks[i][j] = 0;
					CountBlock++;
				}
				else if ((blockX <= Ball_position.x && blockX + 80 >= Ball_position.x) && (blockY >= Ball_position.y && blockY - Ball_radius <= Ball_position.y) && (y_way == 1)) {
					//위쪽 맞았을 때
					Ball_position.y = blockY - Ball_radius; // 블럭에 공이 박히는거 방지
					y_way *= -1; // 방향 전환
					bricks[i][j] = 0;
					CountBlock++;
				}
				else if ((blockY <= Ball_position.y && blockY + 40 >= Ball_position.y) && (blockX - Ball_radius <= Ball_position.x && blockX >= Ball_position.x) && (x_way == 1)) {
					//왼쪽 맞았을 때
					Ball_position.x = blockX - Ball_radius;// 블럭에 공이 박히는거 방지
					x_way *= -1; // 방향 전환
					bricks[i][j] = 0;
					CountBlock++;
				}
				else if ((blockY <= Ball_position.y && blockY + 40 >= Ball_position.y) && (blockX + 80 <= Ball_position.x && blockX + 80 + Ball_radius >= Ball_position.x) && (x_way == -1)) {
					//오른쪽 맞았을 때
					Ball_position.x = blockX + 80 + Ball_radius;// 블럭에 공이 박히는거 방지
					x_way *= -1; // 방향 전환
					bricks[i][j] = 0;
					CountBlock++;
				}
				else if ((blockX + 80 <= Ball_position.x && blockX + 80 + Ball_radius >= Ball_position.x) &&
					(blockY >= Ball_position.y && blockY - Ball_radius <= Ball_position.y) && (y_way == 1) && (x_way == -1)) {
					//오른쪽 위 대각선 맞았을 때
					Ball_position.x = blockX + 80 + Ball_radius;
					Ball_position.y = blockY - Ball_radius;
					x_way *= -1;
					y_way *= -1;
					bricks[i][j] = 0;
					CountBlock++;
				}
				else if ((blockX + 80 <= Ball_position.x && blockX + 80 + Ball_radius >= Ball_position.x) &&
					(blockY + 40 <= Ball_position.y && blockY + 40 + Ball_radius >= Ball_position.y) && (y_way == -1) && (x_way == -1)) {
					//오른쪽 밑 대각선 맞았을 때
					Ball_position.x = blockX + 80 + Ball_radius;
					Ball_position.y = blockY + 40 + Ball_radius;
					x_way *= -1;
					y_way *= -1;
					bricks[i][j] = 0;
					CountBlock++;
				}
				else if ((blockX - Ball_radius <= Ball_position.x && blockX >= Ball_position.x) &&
					(blockY >= Ball_position.y && blockY - Ball_radius <= Ball_position.y) && (y_way == 1) && (x_way == 1)) {
					//왼쪽 위 대각선 맞았을 때
					Ball_position.x = blockX - Ball_radius;
					Ball_position.y = blockY - Ball_radius;
					x_way *= -1;
					y_way *= -1;
					bricks[i][j] = 0;
					CountBlock++;
				}
				else if ((blockX - Ball_radius <= Ball_position.x && blockX >= Ball_position.x) &&
					(blockY + 40 <= Ball_position.y && blockY + 40 + Ball_radius >= Ball_position.y) && (y_way == -1) && (x_way == 1)) {
					//왼쪽 밑 대각선 맞았을 때
					Ball_position.x = blockX - Ball_radius;
					Ball_position.y = blockY + 40 + Ball_radius;
					x_way *= -1;
					y_way *= -1;
					bricks[i][j] = 0;
					CountBlock++;
				}
			}//bricks[i][j]
		}//for(j)
	}//for(i)
	Invalidate();
	//--------------바닥과의 충돌처리--------------
	if (Ball_position.y >= 643) {
		if (Ball_position.y >= 643)
			Ball_position.y = 643;
		KillTimer(0);
		AfxMessageBox(_T("Game Over"));
		if (life == 0)
			life++;
	}
	//--------------모든블럭이 깨졌을 때----------------
	if (CountBlock == 28) {
		if (life == 0)
			life++;
		KillTimer(0);
		AfxMessageBox(_T("Game Clear!!"));
	}
	CWnd::OnTimer(nIDEvent);
}